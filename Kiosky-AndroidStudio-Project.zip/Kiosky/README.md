# Kiosky — Launcher Android "Liquid Glass"

Projet Android Studio complet : un launcher (écran d'accueil) avec des boutons
programmables et personnalisables (couleur, taille, position libre, icône
personnalisée), qui lancent l'application de ton choix. Style visuel verre
dépoli translucide ("Liquid Glass").

## Ouvrir et compiler

1. Installe **Android Studio** (dernière version stable).
2. `File > Open`, sélectionne le dossier `Kiosky/`.
3. Laisse Android Studio générer le wrapper Gradle automatiquement au premier
   sync (il proposera "Create Gradle Wrapper" si besoin), puis laisse-le
   télécharger les dépendances (nécessite Internet).
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. L'APK généré se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.
6. Installe-le sur un téléphone/tablette (active "Sources inconnues" si besoin),
   puis appuie sur le bouton Accueil : Android proposera "Kiosky" comme
   launcher. Choisis "Toujours" pour le définir par défaut.
   (Pour revenir en arrière : Paramètres > Applications > Application par défaut > Application d'accueil.)

## Fonctionnalités incluses

- **Vrai launcher** : déclaré avec `HOME`/`LAUNCHER` dans le manifeste,
  bouton "retour" désactivé pour rester sur l'écran d'accueil.
- **Mode édition** (bouton flottant en bas à droite) :
  - glisser-déposer un bouton n'importe où sur l'écran (position libre) ;
  - bouton "+" pour ajouter un nouveau bouton ;
  - appui long ou clic (en mode édition) sur un bouton pour l'éditer.
- **Personnalisation avancée par bouton** :
  - nom, couleur (palette + possibilité d'étendre avec un sélecteur hex),
  - taille (slider 90–260 dp),
  - icône personnalisée (choisie depuis la galerie),
  - application cible, choisie dans la liste des applications installées.
- **Persistance locale** : la configuration est sauvegardée sur l'appareil
  (DataStore + JSON), rien n'est envoyé sur un serveur.
- **Style Liquid Glass** : superposition de calques (flou, dégradé teinté,
  liseré lumineux) pour un rendu verre dépoli translucide façon
  visionOS/iOS 18.

## Pistes d'amélioration (non incluses ici, pour rester raisonnable)

- Sélecteur de couleur hex libre (roue chromatique) en plus des pastilles.
- Poignée de redimensionnement au doigt (actuellement : slider dans la boîte d'édition).
- Fond d'écran réel de l'utilisateur (`WallpaperManager`) au lieu du dégradé.
- Grille d'alignement / snapping lors du déplacement des boutons.
- Export/import de la configuration (sauvegarde/partage entre appareils).

## Structure du projet

```
Kiosky/
  app/src/main/java/com/kiosky/launcher/
    MainActivity.kt              -> point d'entrée
    LauncherViewModel.kt         -> état des boutons + logique
    data/KioskyButton.kt         -> modèle de données d'un bouton
    data/ButtonRepository.kt     -> persistance (DataStore/JSON)
    ui/LauncherScreen.kt         -> écran principal, positionnement libre
    ui/GlassButton.kt            -> rendu visuel "Liquid Glass"
    ui/EditButtonDialog.kt       -> édition avancée d'un bouton
    ui/AppPickerDialog.kt        -> choix de l'application à lancer
    ui/theme/                    -> couleurs et thème Compose
```

Remplace l'icône `res/mipmap-anydpi-v26/ic_launcher.xml` (actuellement un
placeholder) par ta propre icône avant publication.
